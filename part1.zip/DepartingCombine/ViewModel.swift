import Combine

class ViewModel {
    @Published private var counter = 0
    lazy private(set) var numbers = $counter.values
    
    func next() {
        counter = Int.random(in: 0...50)
    }
}
