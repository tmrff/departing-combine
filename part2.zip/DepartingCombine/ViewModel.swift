import Foundation

let notificationName = Notification.Name("CounterNotificaiton")
let counterKey = "counterKey"

class ViewModel {
    let numbers = NotificationCenter.default
        .notifications(named: notificationName)
        .compactMap(\.userInfo)
        .compactMap { userInfo in userInfo[counterKey] as? Int }
}

extension ViewModel {
    func next() {
        NotificationCenter.default
            .post(name: notificationName,
                  object: self,
                  userInfo: [counterKey: Int.random(in: 1...50)]
            )
    }
}
