import Foundation

class ViewModel {
    private var continuation: AsyncStream<Int>.Continuation?
    lazy private(set) var numbers = AsyncStream(Int.self) { continuation in
        self.continuation = continuation
    }
}

extension ViewModel {
    func next() {
        continuation?.yield(Int.random(in: 1...50))
    }
}
